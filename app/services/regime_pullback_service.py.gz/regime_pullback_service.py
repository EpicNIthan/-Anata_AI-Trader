from __future__ import annotations

"""Single paper-only scheduler and persistent execution service for regime_pullback_v1."""

import asyncio
import hashlib
import logging
import os
import socket
import uuid
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import desc, func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.config import settings
from app.db.models import AccountEquity, AiDecision, Candle, ExternalDataEvent, PaperTrade, Position
from app.db.session import SessionLocal, ping_database
from app.strategies.regime_models import (
    RegimeDailyRiskState,
    RegimeDecisionRecord,
    RegimePaperAccount,
    RegimePaperFill,
    RegimePaperOrder,
    RegimePositionMeta,
    RegimeStrategyLock,
    RegimeSymbolRiskState,
)
from app.strategies.regime_pullback_v1 import (
    FEATURE_SCHEMA_VERSION,
    STRATEGY_NAME,
    STRATEGY_VERSION,
    CandleBar,
    DecisionAction,
    FeatureSnapshot,
    DerivativesSnapshot,
    PositionState,
    Regime,
    ReasonCode,
    RiskContext,
    StrategyConfig,
    build_feature_snapshot,
    dec,
    evaluate_entry,
    evaluate_exit,
    executable_exit_reference,
    gross_pnl,
    unrealized_pnl,
    latest_completed_close,
    paper_fill_price,
    resample_complete_bars,
)

logger = logging.getLogger(__name__)
ACCOUNT_ID = STRATEGY_NAME
LOCK_NAME = f"strategy:{STRATEGY_NAME}"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value in (None, ""):
        return default
    return value.strip().strip('"').strip("'").lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    value = os.getenv(name)
    return default if value in (None, "") else int(value)


def _decimal(name: str, default: str, *, percent: bool = False) -> Decimal:
    value = os.getenv(name)
    result = Decimal(default if value in (None, "") else value)
    return result / Decimal("100") if percent else result


def _float(name: str, default: float) -> float:
    value = os.getenv(name)
    return default if value in (None, "") else float(value)


def _symbols() -> list[str]:
    raw = os.getenv("TRADING_SYMBOLS") or os.getenv("AUTO_TRADER_SYMBOLS") or "BTCUSDT,ETHUSDT,SOLUSDT"
    return list(dict.fromkeys(item.strip().upper() for item in raw.split(",") if item.strip()))


def load_strategy_config() -> StrategyConfig:
    leverage = _decimal("FIXED_LEVERAGE", "1")
    if leverage != Decimal("1"):
        raise RuntimeError("regime_pullback_v1 enforces exactly 1x leverage")
    return StrategyConfig(
        fixed_leverage=leverage,
        risk_per_trade_pct=_decimal("RISK_PER_TRADE_PCT", "0.25", percent=True),
        max_symbol_exposure_pct=_decimal("MAX_SYMBOL_EXPOSURE_PCT", "10", percent=True),
        max_total_exposure_pct=_decimal("MAX_TOTAL_EXPOSURE_PCT", "20", percent=True),
        max_open_positions=_int("MAX_OPEN_POSITIONS", 2),
        max_positions_per_symbol=_int("MAX_POSITIONS_PER_SYMBOL", 1),
        max_trades_per_symbol_per_day=_int("MAX_TRADES_PER_SYMBOL_PER_DAY", 3),
        max_total_trades_per_day=_int("MAX_TOTAL_TRADES_PER_DAY", 8),
        daily_loss_limit_pct=_decimal("DAILY_LOSS_LIMIT_PCT", "1", percent=True),
        max_consecutive_losses=_int("MAX_CONSECUTIVE_LOSSES", 3),
        cooldown_bars=_int("COOLDOWN_BARS", 8),
        min_confidence=_float("MIN_CONFIDENCE", 0.75),
        adx_min=_float("ADX_MIN", 20.0),
        atr_pct_min=_float("ATR_PCT_MIN", 0.0025),
        atr_pct_max=_float("ATR_PCT_MAX", 0.03),
        max_spread_bps=_float("MAX_SPREAD_BPS", 8.0),
        max_abs_funding_rate=_float("MAX_ABS_FUNDING_RATE", 0.0005),
        atr_stop_multiplier=_decimal("ATR_STOP_MULTIPLIER", "1.5"),
        atr_take_profit_multiplier=_decimal("ATR_TAKE_PROFIT_MULTIPLIER", "2.5"),
        trailing_atr_multiplier=_decimal("TRAILING_ATR_MULTIPLIER", "1"),
        break_even_at_r=_decimal("BREAK_EVEN_AT_R", "1"),
        trailing_start_at_r=_decimal("TRAILING_START_AT_R", "1.5"),
        time_exit_bars=_int("TIME_EXIT_BARS", 16),
        time_exit_min_r=_decimal("TIME_EXIT_MIN_R", "0.5"),
        fee_rate_per_side=_decimal("PAPER_FEE_RATE_PER_SIDE", "0.0004"),
        slippage_rate_per_side=_decimal("PAPER_SLIPPAGE_RATE_PER_SIDE", "0.0002"),
        estimated_spread_bps=_decimal("PAPER_ESTIMATED_SPREAD_BPS", "4"),
        stale_exit_timeout_minutes=_int("STALE_DATA_SAFETY_TIMEOUT_MINUTES", 60),
        min_quantity=_decimal("PAPER_MIN_QUANTITY", "0.000001"),
        quantity_step=_decimal("PAPER_QUANTITY_STEP", "0.000001"),
        min_notional=_decimal("PAPER_MIN_NOTIONAL", "5"),
    )


@dataclass
class AutoTraderState:
    running: bool = False
    enabled: bool = False
    paper_only: bool = True
    strategy_name: str = STRATEGY_NAME
    strategy_version: str = STRATEGY_VERSION
    feature_schema_version: str = FEATURE_SCHEMA_VERSION
    symbols: list[str] = field(default_factory=_symbols)
    interval_seconds: int = 30
    cycles: int = 0
    decisions: int = 0
    entries: int = 0
    exits: int = 0
    rejected: int = 0
    holds: int = 0
    last_run_at: str | None = None
    latest_processed_decision_candle: str | None = None
    last_error: str | None = None
    last_decision: dict[str, Any] | None = None
    lock_owner: str | None = None
    lock_acquired: bool = False
    strategy_mode: str = STRATEGY_NAME
    model_strategy_enabled: bool = False

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class AutoTraderService:
    """Compatibility service name used by existing API routes and app startup."""

    name = STRATEGY_NAME

    def __init__(self, *, symbols: list[str] | None = None, interval_seconds: int | None = None) -> None:
        self.symbols = symbols or _symbols()
        self.interval_seconds = max(interval_seconds or _int("STRATEGY_POLL_INTERVAL_SECONDS", 30), 5)
        self.config = load_strategy_config()
        self.owner_id = f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:10]}"
        self.state = AutoTraderState(
            enabled=_bool("AUTO_TRADER_ENABLED", True),
            symbols=self.symbols,
            interval_seconds=self.interval_seconds,
            lock_owner=self.owner_id,
        )
        self._task: asyncio.Task[None] | None = None
        self._stop_event: asyncio.Event | None = None

    def _assert_paper_only(self) -> None:
        mode = (os.getenv("TRADING_MODE") or getattr(settings, "trading_mode", "paper")).lower()
        live_enabled = _bool("LIVE_TRADING_ENABLED", False)
        if mode != "paper" or live_enabled:
            raise RuntimeError("regime_pullback_v1 is paper-only; set TRADING_MODE=paper and LIVE_TRADING_ENABLED=false")

    def set_strategy_mode(self, mode: str) -> dict[str, Any]:
        normalized = mode.strip().lower()
        if normalized not in {STRATEGY_NAME, "bot", "paper", "rule", "rule-based"}:
            raise ValueError(f"only {STRATEGY_NAME} is available")
        self.state.strategy_mode = STRATEGY_NAME
        return self.status()

    def status(self) -> dict[str, Any]:
        summary: dict[str, Any] = self.state.as_dict()
        try:
            with SessionLocal() as session:
                account = session.get(RegimePaperAccount, ACCOUNT_ID)
                positions = self._open_positions(session)
                latest = session.scalar(
                    select(RegimeDecisionRecord).order_by(desc(RegimeDecisionRecord.candle_close_time)).limit(1)
                )
                daily = self._daily_state(session, account, create=False) if account else None
                recent = session.scalars(
                    select(RegimeDecisionRecord)
                    .order_by(desc(RegimeDecisionRecord.candle_close_time))
                    .limit(max(len(self.symbols), 3))
                ).all()
                summary.update(
                    {
                        "paper_account": self._account_summary(account, positions) if account else None,
                        "open_positions": [self._position_summary(session, p) for p in positions],
                        "latest_processed_decision_candle": latest.candle_close_time.isoformat() if latest else None,
                        "current_symbols": [self._decision_summary(row) for row in recent],
                        "daily_risk": self._daily_summary(daily) if daily else None,
                        "live_trading_enabled": False,
                        "execution_adapter": "internal deterministic paper ledger only",
                    }
                )
        except Exception as exc:
            summary["status_error"] = str(exc)
        return summary

    async def start(self) -> dict[str, Any]:
        self._assert_paper_only()
        if self._task and not self._task.done():
            return self.status()
        self._stop_event = asyncio.Event()
        self.state.enabled = True
        self.state.running = True
        self.state.last_error = None
        self._task = asyncio.create_task(self._run_loop(self._stop_event), name=STRATEGY_NAME)
        return self.status()

    async def stop(self) -> dict[str, Any]:
        if self._stop_event:
            self._stop_event.set()
        if self._task and not self._task.done():
            try:
                await asyncio.wait_for(self._task, timeout=5)
            except asyncio.TimeoutError:
                self._task.cancel()
                try:
                    await self._task
                except asyncio.CancelledError:
                    pass
        self.state.running = False
        self.state.enabled = False
        self._release_lease()
        return self.status()

    async def _run_loop(self, stop_event: asyncio.Event) -> None:
        try:
            while not stop_event.is_set():
                await asyncio.to_thread(self.run_once)
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=self.interval_seconds)
                except asyncio.TimeoutError:
                    pass
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("%s scheduler stopped", STRATEGY_NAME)
            self.state.last_error = str(exc)
        finally:
            self.state.running = False

    def run_once(self, *, now: datetime | None = None) -> dict[str, Any]:
        self._assert_paper_only()
        now = (now or utc_now()).astimezone(timezone.utc)
        if not self._acquire_lease(now):
            self.state.lock_acquired = False
            self.state.last_error = "another Railway instance owns the strategy lease"
            return self.status()
        self.state.lock_acquired = True
        # Allow the collector a small grace period at the exact candle boundary.
        # This avoids permanently logging DATA_MISSING for a candle whose final 1m
        # row is still being committed.
        grace_seconds = max(_int("DECISION_CLOSE_GRACE_SECONDS", 10), 0)
        decision_close = latest_completed_close(now - timedelta(seconds=grace_seconds), 15)
        cycle_rows: list[dict[str, Any]] = []
        with SessionLocal() as session:
            account = self._get_or_create_account(session)
            self._daily_state(session, account, create=True)
            for symbol in self.symbols:
                try:
                    cycle_rows.append(self._process_symbol(session, account, symbol, decision_close, now))
                    session.commit()
                except IntegrityError:
                    session.rollback()
                    cycle_rows.append({"symbol": symbol, "action": "HOLD", "reason_codes": [ReasonCode.DUPLICATE_DECISION.value]})
                except Exception as exc:
                    session.rollback()
                    logger.exception("strategy cycle failed for %s", symbol)
                    cycle_rows.append({"symbol": symbol, "action": "ERROR", "reason_codes": [ReasonCode.DATA_MISSING.value], "error": str(exc)})
                    self.state.last_error = str(exc)
            self._snapshot_equity(session, account)
            session.commit()
        self.state.cycles += 1
        self.state.decisions += sum(1 for row in cycle_rows if row.get("decision_id"))
        for row in cycle_rows:
            action = row.get("action", "")
            if action.startswith("ENTER_"):
                self.state.entries += 1
            elif action.startswith("EXIT_"):
                self.state.exits += 1
            elif action.startswith("REJECTED_"):
                self.state.rejected += 1
            elif action == "HOLD":
                self.state.holds += 1
        self.state.last_run_at = now.isoformat()
        self.state.latest_processed_decision_candle = decision_close.isoformat()
        self.state.last_decision = cycle_rows[-1] if cycle_rows else None
        if not any(row.get("action") == "ERROR" for row in cycle_rows):
            self.state.last_error = None
        return self.status()

    def _acquire_lease(self, now: datetime) -> bool:
        lease_until = now + timedelta(seconds=max(self.interval_seconds * 3, 90))
        with SessionLocal() as session:
            # A conditional UPDATE is atomic in PostgreSQL and SQLite, unlike a
            # read-then-write race where two Railway instances can both believe
            # they acquired an expired lease.
            result = session.execute(
                update(RegimeStrategyLock)
                .where(
                    RegimeStrategyLock.lock_name == LOCK_NAME,
                    (RegimeStrategyLock.owner_id == self.owner_id)
                    | (RegimeStrategyLock.lease_until <= now),
                )
                .values(owner_id=self.owner_id, lease_until=lease_until, updated_at=now)
            )
            if result.rowcount == 1:
                session.commit()
                return True
            session.rollback()
            session.add(RegimeStrategyLock(lock_name=LOCK_NAME, owner_id=self.owner_id, lease_until=lease_until))
            try:
                session.commit()
                return True
            except IntegrityError:
                session.rollback()
                return False

    def _release_lease(self) -> None:
        try:
            with SessionLocal() as session:
                row = session.get(RegimeStrategyLock, LOCK_NAME)
                if row and row.owner_id == self.owner_id:
                    row.lease_until = utc_now()
                    session.commit()
        except Exception:
            logger.exception("failed to release strategy lease")

    def _process_symbol(
        self,
        session: Session,
        account: RegimePaperAccount,
        symbol: str,
        decision_close: datetime,
        now: datetime,
    ) -> dict[str, Any]:
        existing = session.scalar(
            select(RegimeDecisionRecord).where(
                RegimeDecisionRecord.strategy_version == STRATEGY_VERSION,
                RegimeDecisionRecord.symbol == symbol,
                RegimeDecisionRecord.candle_close_time == decision_close,
            )
        )
        if existing:
            return self._decision_summary(existing)
        position = session.scalar(
            select(Position).where(
                Position.paper_account_id == ACCOUNT_ID,
                Position.symbol == symbol,
                Position.status == "OPEN",
            )
        )
        try:
            feature = self._build_feature(session, symbol, decision_close, now)
        except ValueError as exc:
            if position is not None:
                meta = session.scalar(select(RegimePositionMeta).where(RegimePositionMeta.position_id == position.id))
                if meta is None:
                    raise RuntimeError(f"missing strategy metadata for position {position.id}")
                if meta.stale_since is None:
                    meta.stale_since = now
                feature = self._unavailable_feature(symbol, decision_close, now, float(position.current_price or position.entry_price), float(meta.initial_atr))
                evaluation = self._evaluate_existing_position(session, account, position, feature)
                reasons = evaluation["reasons"] if evaluation["exit"] else [ReasonCode.DATA_MISSING.value]
                row = self._new_decision(feature, evaluation["action"], evaluation["confidence"], evaluation["components"], reasons, False)
                session.add(row)
                session.flush()
                if evaluation["exit"]:
                    self._close_position(session, account, position, row, feature, evaluation["exit"])
                else:
                    row.position_id = position.id
                self._mirror_decision(session, row)
                return self._decision_summary(row)
            row = RegimeDecisionRecord(
                strategy_name=STRATEGY_NAME,
                strategy_version=STRATEGY_VERSION,
                feature_schema_version=FEATURE_SCHEMA_VERSION,
                symbol=symbol,
                candle_close_time=decision_close,
                market_data_time=decision_close,
                feature_time=now,
                decision_time=now,
                source_timestamps={},
                data_fresh=False,
                data_complete=False,
                missing_feature_flags=["required_candle_history"],
                regime=Regime.NEUTRAL.value,
                action=DecisionAction.HOLD.value,
                confidence=0.0,
                confidence_components={},
                indicator_values={"error": str(exc)},
                spread_estimated=True,
                spread_method="unavailable",
                fee_rate=self.config.fee_rate_per_side,
                slippage_rate=self.config.slippage_rate_per_side,
                rejection_codes=[ReasonCode.DATA_MISSING.value],
                risk_result={"approved": False, "shadow": False},
                payload={"paper_only": True, "live_order_path": False},
            )
            session.add(row)
            session.flush()
            self._mirror_decision(session, row)
            return self._decision_summary(row)
        if position:
            evaluation = self._evaluate_existing_position(session, account, position, feature)
            row = self._new_decision(feature, evaluation["action"], evaluation["confidence"], evaluation["components"], evaluation["reasons"], False)
            session.add(row)
            session.flush()
            if evaluation["exit"]:
                self._close_position(session, account, position, row, feature, evaluation["exit"])
            else:
                self._update_position_meta(session, position, evaluation["exit_eval"])
                row.position_id = position.id
            self._mirror_decision(session, row)
            return self._decision_summary(row)
        context = self._risk_context(session, account, symbol, decision_close)
        result = evaluate_entry(feature, context, self.config)
        row = self._new_decision(
            feature,
            result.action,
            result.confidence,
            result.confidence_components.as_dict(),
            [reason.value for reason in result.reason_codes],
            result.shadow_decision,
            result,
        )
        session.add(row)
        session.flush()
        if result.risk_approved and result.quantity and result.quantity.approved_quantity > 0:
            self._open_position(session, account, row, feature, result)
        self._mirror_decision(session, row)
        return self._decision_summary(row)

    def _unavailable_feature(self, symbol: str, decision_close: datetime, now: datetime, price: float, atr_value: float) -> FeatureSnapshot:
        safe_price = max(price, 0.000001)
        safe_atr = max(atr_value, safe_price * 0.004)
        return FeatureSnapshot(
            symbol=symbol, decision_time=now, candle_close_time=decision_close, feature_time=now,
            market_data_time=decision_close, source_timestamps={}, data_fresh=False, data_complete=False,
            candle_complete=True, missing_intervals=True, close=safe_price, high=safe_price, low=safe_price,
            volume=0.0, previous_high=safe_price, previous_low=safe_price, previous_close=safe_price,
            ema20=safe_price, current_low=safe_price, current_high=safe_price, previous_low_15m=safe_price,
            previous_high_15m=safe_price, rsi14=50.0, previous_rsi14=50.0, atr15m=safe_atr,
            median_volume20=0.0, regime=Regime.NEUTRAL, ema50_1h=safe_price, ema200_1h=safe_price,
            ema50_1h_three_bars_ago=safe_price, adx14_1h=0.0, close_1h=safe_price,
            spread_bps=float(self.config.estimated_spread_bps), spread_estimated=True,
            spread_method="persistent_stale_data_fallback", derivatives=DerivativesSnapshot(),
        )

    def _build_feature(self, session: Session, symbol: str, decision_close: datetime, now: datetime):
        rows = session.scalars(
            select(Candle)
            .where(
                Candle.symbol == symbol,
                Candle.interval == "1m",
                Candle.is_closed.is_(True),
                Candle.close_time <= decision_close,
            )
            .order_by(desc(Candle.open_time))
            .limit(14_000)
        ).all()
        rows.reverse()
        bars = [
            CandleBar(
                open_time=row.open_time,
                close_time=row.close_time or (row.open_time + timedelta(minutes=1)),
                open=row.open,
                high=row.high,
                low=row.low,
                close=row.close,
                volume=row.volume,
                source_timestamps=((row.close_time or row.open_time).isoformat(),),
                complete=bool(row.is_closed),
            )
            for row in rows
        ]
        bars15 = resample_complete_bars(bars, 15)
        bars1h = resample_complete_bars(bars, 60)
        derivatives = self._latest_derivatives(session, symbol, decision_close)
        feature = build_feature_snapshot(
            symbol=symbol,
            decision_close=decision_close,
            bars_15m=bars15,
            bars_1h=bars1h,
            now=now,
            derivatives=derivatives,
        )
        expected = 15
        recent = [bar for bar in bars if decision_close - timedelta(minutes=expected) < bar.close_time <= decision_close]
        contiguous = len(recent) == expected and all(
            int((recent[index].open_time - recent[index - 1].open_time).total_seconds()) == 60
            for index in range(1, len(recent))
        )
        return replace(feature, missing_intervals=not contiguous, data_complete=feature.data_complete and contiguous)

    def _latest_derivatives(self, session: Session, symbol: str, as_of: datetime) -> DerivativesSnapshot:
        events = session.scalars(
            select(ExternalDataEvent)
            .where(ExternalDataEvent.symbol == symbol, ExternalDataEvent.event_time <= as_of)
            .order_by(desc(ExternalDataEvent.event_time))
            .limit(50)
        ).all()
        oi: float | None = None
        funding: float | None = None
        taker: float | None = None
        timestamp: datetime | None = None
        for event in events:
            kind = (event.data_type or "").lower()
            payload = event.payload or {}
            value = event.numeric_value
            timestamp = max(timestamp, event.event_time) if timestamp else event.event_time
            if funding is None and "funding" in kind:
                funding = float(value if value is not None else payload.get("funding_rate")) if (value is not None or payload.get("funding_rate") is not None) else None
            if oi is None and ("open_interest_change" in kind or "open-interest-change" in kind):
                raw = value if value is not None else payload.get("open_interest_change")
                oi = float(raw) if raw is not None else None
            if taker is None and "taker" in kind:
                raw = value if value is not None else payload.get("taker_imbalance", payload.get("imbalance"))
                taker = float(raw) if raw is not None else None
            if oi is not None and funding is not None and taker is not None:
                break
        return DerivativesSnapshot(open_interest_change=oi, funding_rate=funding, taker_imbalance=taker, timestamp=timestamp)

    def _risk_context(self, session: Session, account: RegimePaperAccount, symbol: str, candle_close: datetime) -> RiskContext:
        positions = self._open_positions(session)
        daily = self._daily_state(session, account, create=True)
        symbol_state = self._symbol_state(session, symbol, daily.utc_date, create=True)
        equity = self._equity(account, positions)
        return RiskContext(
            paper_equity=equity,
            paper_cash=dec(account.cash_balance),
            current_total_open_notional=sum((dec(p.notional) for p in positions), Decimal("0")),
            open_positions=len(positions),
            symbol_has_position=any(p.symbol == symbol for p in positions),
            symbol_trades_today=symbol_state.new_trades,
            portfolio_trades_today=daily.new_trades,
            starting_day_equity=dec(daily.starting_equity),
            day_net_pnl=dec(daily.realized_trading_pnl) - dec(daily.total_fees),
            consecutive_losses=daily.consecutive_losses,
            cooldown_active=bool(symbol_state.cooldown_until_candle and symbol_state.cooldown_until_candle > candle_close),
            components_healthy=self._components_healthy(),
            leverage_requested=Decimal("1"),
        )

    def _components_healthy(self) -> bool:
        try:
            return bool(ping_database()) and self.config.fixed_leverage == Decimal("1")
        except Exception:
            return False

    def _new_decision(
        self,
        feature,
        action: DecisionAction,
        confidence: float,
        components: dict[str, Any],
        reasons: list[str],
        shadow: bool,
        result=None,
    ) -> RegimeDecisionRecord:
        quantity = result.quantity if result else None
        missing = []
        if feature.derivatives.open_interest_change is None:
            missing.append("open_interest_change")
        if feature.derivatives.funding_rate is None:
            missing.append("funding_rate")
        if feature.derivatives.taker_imbalance is None:
            missing.append("taker_imbalance")
        return RegimeDecisionRecord(
            strategy_name=STRATEGY_NAME,
            strategy_version=STRATEGY_VERSION,
            feature_schema_version=FEATURE_SCHEMA_VERSION,
            symbol=feature.symbol,
            candle_close_time=feature.candle_close_time,
            market_data_time=feature.market_data_time,
            feature_time=feature.feature_time,
            decision_time=feature.decision_time,
            source_timestamps=feature.source_timestamps,
            data_fresh=feature.data_fresh,
            data_complete=feature.data_complete,
            missing_feature_flags=missing,
            regime=feature.regime.value,
            action=action.value,
            confidence=confidence,
            confidence_components=components,
            indicator_values=feature.as_payload(),
            spread_bps=dec(feature.spread_bps),
            spread_estimated=feature.spread_estimated,
            spread_method=feature.spread_method,
            fee_rate=self.config.fee_rate_per_side,
            slippage_rate=self.config.slippage_rate_per_side,
            funding_rate=dec(feature.derivatives.funding_rate) if feature.derivatives.funding_rate is not None else None,
            open_interest_change=dec(feature.derivatives.open_interest_change) if feature.derivatives.open_interest_change is not None else None,
            taker_imbalance=dec(feature.derivatives.taker_imbalance) if feature.derivatives.taker_imbalance is not None else None,
            rejection_codes=reasons,
            risk_result={"approved": bool(result and result.risk_approved), "shadow": shadow},
            requested_quantity=quantity.requested_quantity if quantity else Decimal("0"),
            approved_quantity=quantity.approved_quantity if quantity else Decimal("0"),
            risk_budget=quantity.risk_budget if quantity else Decimal("0"),
            stop_distance=quantity.stop_distance if quantity else Decimal("0"),
            estimated_notional=quantity.estimated_notional if quantity else Decimal("0"),
            entry_reason="REGIME_PULLBACK_CONFIRMED" if action in {DecisionAction.ENTER_LONG, DecisionAction.ENTER_SHORT} else None,
            shadow_decision=shadow,
            payload={"paper_only": True, "live_order_path": False},
        )

    def _open_position(self, session: Session, account: RegimePaperAccount, decision: RegimeDecisionRecord, feature, result) -> None:
        side = "LONG" if result.action == DecisionAction.ENTER_LONG else "SHORT"
        order_side = "BUY" if side == "LONG" else "SELL"
        reference = result.entry_price_reference
        fill_price = paper_fill_price(reference, order_side, self.config)
        quantity = result.quantity.approved_quantity
        notional = fill_price * quantity
        fee = notional * self.config.fee_rate_per_side
        client_order_id = self._stable_id("entry", feature.symbol, feature.candle_close_time.isoformat(), STRATEGY_VERSION)
        order = RegimePaperOrder(
            client_order_id=client_order_id,
            decision_id=decision.id,
            symbol=feature.symbol,
            order_side=order_side,
            position_side=side,
            quantity=quantity,
            reference_price=reference,
            fill_price=fill_price,
            notional=notional,
            fee=fee,
            slippage_cost=abs(fill_price - reference) * quantity,
            spread_cost=abs(reference - dec(feature.close)) * quantity,
            realized_trading_pnl=Decimal("0"),
            is_entry=True,
            reason_code="ENTRY",
            payload={"spread_estimated": feature.spread_estimated},
        )
        session.add(order)
        session.flush()
        position = Position(
            symbol=feature.symbol,
            paper_account_id=ACCOUNT_ID,
            side=side,
            quantity=float(quantity),
            entry_price=float(fill_price),
            current_price=float(fill_price),
            notional=float(notional),
            margin_used=float(notional),
            leverage=1.0,
            stop_loss=float(result.stop_price),
            take_profit=float(result.target_price),
            realized_pnl=0.0,
            unrealized_pnl=0.0,
            status="OPEN",
            opened_at=feature.decision_time,
        )
        session.add(position)
        session.flush()
        order.position_id = position.id
        fill_id = self._stable_id("fill", client_order_id)
        session.add(RegimePaperFill(fill_id=fill_id, order_id=order.id, quantity=quantity, fill_price=fill_price, fee=fee))
        meta = RegimePositionMeta(
            position_id=position.id,
            strategy_version=STRATEGY_VERSION,
            entry_decision_id=decision.id,
            initial_atr=dec(feature.atr15m),
            initial_stop=result.stop_price,
            initial_target=result.target_price,
            initial_risk_per_unit=result.quantity.stop_distance,
            entry_fee=fee,
            total_costs=fee,
            highest_completed_close=dec(feature.close),
            lowest_completed_close=dec(feature.close),
        )
        session.add(meta)
        account.cash_balance = dec(account.cash_balance) - fee
        account.total_fees = dec(account.total_fees) + fee
        decision.paper_order_id = client_order_id
        decision.position_id = position.id
        daily = self._daily_state(session, account, create=True)
        symbol_state = self._symbol_state(session, feature.symbol, daily.utc_date, create=True)
        daily.new_trades += 1
        symbol_state.new_trades += 1
        self._mirror_trade(session, position, order, account, realized=Decimal("0"))

    def _evaluate_existing_position(self, session: Session, account: RegimePaperAccount, position: Position, feature) -> dict[str, Any]:
        meta = session.scalar(select(RegimePositionMeta).where(RegimePositionMeta.position_id == position.id))
        if meta is None:
            raise RuntimeError(f"missing strategy metadata for position {position.id}")
        if feature.data_fresh and feature.data_complete:
            meta.stale_since = None
        elif meta.stale_since is None:
            meta.stale_since = feature.decision_time
        exit_reference = executable_exit_reference(feature, position.side)
        position.current_price = float(exit_reference)
        position.unrealized_pnl = float(unrealized_pnl(position.side, dec(position.entry_price), exit_reference, dec(position.quantity)))
        meta.highest_completed_close = max(dec(meta.highest_completed_close or feature.close), dec(feature.close))
        meta.lowest_completed_close = min(dec(meta.lowest_completed_close or feature.close), dec(feature.close))
        state = PositionState(
            position_id=str(position.id),
            symbol=position.symbol,
            side=position.side,
            quantity=dec(position.quantity),
            entry_price=dec(position.entry_price),
            initial_stop_distance=dec(meta.initial_risk_per_unit),
            stop_price=dec(position.stop_loss),
            target_price=dec(position.take_profit),
            atr_at_entry=dec(meta.initial_atr),
            opened_at=position.opened_at,
            bars_held=meta.bars_held + 1,
            max_favorable_r=self._max_favorable_r(meta, position),
            entry_fee=dec(meta.entry_fee),
            exit_fee=dec(meta.exit_fee),
            stale_since=meta.stale_since,
            trailing_active=meta.trailing_active,
            break_even_active=meta.break_even_active,
        )
        daily = self._daily_state(session, account, create=True)
        exit_eval = evaluate_exit(
            state,
            feature,
            self.config,
            daily_circuit_breaker=daily.circuit_breaker,
            admin_shutdown=account.administrative_shutdown,
        )
        if exit_eval.should_exit:
            return {
                "action": exit_eval.action,
                "confidence": 1.0,
                "components": {},
                "reasons": [exit_eval.reason_code.value],
                "exit": exit_eval,
                "exit_eval": exit_eval,
            }
        return {
            "action": DecisionAction.HOLD,
            "confidence": 0.0,
            "components": {},
            "reasons": [],
            "exit": None,
            "exit_eval": exit_eval,
        }

    def _max_favorable_r(self, meta: RegimePositionMeta, position: Position) -> Decimal:
        high = dec(meta.highest_completed_close or position.current_price)
        low = dec(meta.lowest_completed_close or position.current_price)
        distance = dec(meta.initial_risk_per_unit)
        if distance <= 0:
            return Decimal("0")
        favorable = high - dec(position.entry_price) if position.side == "LONG" else dec(position.entry_price) - low
        return max(favorable / distance, Decimal("0"))

    def _update_position_meta(self, session: Session, position: Position, exit_eval) -> None:
        meta = session.scalar(select(RegimePositionMeta).where(RegimePositionMeta.position_id == position.id))
        meta.bars_held += 1
        meta.break_even_active = exit_eval.break_even_active
        meta.trailing_active = exit_eval.trailing_active
        position.stop_loss = float(exit_eval.updated_stop_price)

    def _close_position(self, session: Session, account: RegimePaperAccount, position: Position, decision: RegimeDecisionRecord, feature, exit_eval) -> None:
        meta = session.scalar(select(RegimePositionMeta).where(RegimePositionMeta.position_id == position.id))
        close_event_id = self._stable_id("close", str(position.id), feature.candle_close_time.isoformat())
        if meta.close_event_id:
            raise RuntimeError("position close event already exists")
        reference = exit_eval.exit_reference_price or executable_exit_reference(feature, position.side)
        order_side = "SELL" if position.side == "LONG" else "BUY"
        fill_price = paper_fill_price(reference, order_side, self.config)
        quantity = dec(position.quantity)
        notional = fill_price * quantity
        fee = notional * self.config.fee_rate_per_side
        realized = gross_pnl(position.side, dec(position.entry_price), fill_price, quantity)
        client_order_id = self._stable_id("exit", str(position.id), exit_eval.reason_code.value, feature.candle_close_time.isoformat())
        order = RegimePaperOrder(
            client_order_id=client_order_id,
            decision_id=decision.id,
            position_id=position.id,
            symbol=position.symbol,
            order_side=order_side,
            position_side=position.side,
            quantity=quantity,
            reference_price=reference,
            fill_price=fill_price,
            notional=notional,
            fee=fee,
            slippage_cost=abs(fill_price - reference) * quantity,
            spread_cost=abs(reference - dec(feature.close)) * quantity,
            realized_trading_pnl=realized,
            is_entry=False,
            reason_code=exit_eval.reason_code.value,
        )
        session.add(order)
        session.flush()
        session.add(RegimePaperFill(fill_id=self._stable_id("fill", client_order_id), order_id=order.id, quantity=quantity, fill_price=fill_price, fee=fee))
        account.cash_balance = dec(account.cash_balance) + realized - fee
        account.realized_trading_pnl = dec(account.realized_trading_pnl) + realized
        account.total_fees = dec(account.total_fees) + fee
        position.current_price = float(fill_price)
        position.realized_pnl = float(realized)
        position.unrealized_pnl = 0.0
        position.status = "CLOSED"
        position.closed_at = feature.decision_time
        meta.exit_fee = fee
        meta.total_costs = dec(meta.total_costs) + fee
        meta.close_event_id = close_event_id
        meta.closed_reason = exit_eval.reason_code.value
        meta.bars_held += 1
        decision.paper_order_id = client_order_id
        decision.position_id = position.id
        decision.exit_reason = exit_eval.reason_code.value
        daily = self._daily_state(session, account, create=True)
        daily.realized_trading_pnl = dec(daily.realized_trading_pnl) + realized
        daily.total_fees = dec(daily.total_fees) + fee
        net_trade = realized - dec(meta.entry_fee) - fee
        daily.consecutive_losses = daily.consecutive_losses + 1 if net_trade < 0 else 0
        net_day = dec(daily.realized_trading_pnl) - dec(daily.total_fees)
        if net_day <= -(dec(daily.starting_equity) * self.config.daily_loss_limit_pct) or daily.consecutive_losses >= self.config.max_consecutive_losses:
            daily.circuit_breaker = True
        symbol_state = self._symbol_state(session, position.symbol, daily.utc_date, create=True)
        symbol_state.cooldown_until_candle = feature.candle_close_time + timedelta(minutes=15 * self.config.cooldown_bars)
        meta.cooldown_until_candle = symbol_state.cooldown_until_candle
        self._mirror_trade(session, position, order, account, realized=realized)

    def _get_or_create_account(self, session: Session) -> RegimePaperAccount:
        account = session.get(RegimePaperAccount, ACCOUNT_ID)
        if account is None:
            start = dec(os.getenv("PAPER_START_BALANCE") or "10000")
            account = RegimePaperAccount(account_id=ACCOUNT_ID, cash_balance=start, starting_balance=start)
            session.add(account)
            session.flush()
        return account

    def reset_paper_account(self, session: Session) -> dict[str, Any]:
        """Reset only this strategy's paper account; collected/research data is untouched."""
        if self._open_positions(session):
            raise RuntimeError("close open strategy positions before resetting the paper account")
        account = self._get_or_create_account(session)
        start = dec(os.getenv("PAPER_START_BALANCE") or "10000")
        account.cash_balance = start
        account.starting_balance = start
        account.realized_trading_pnl = Decimal("0")
        account.total_fees = Decimal("0")
        account.funding_cost = Decimal("0")
        account.administrative_shutdown = False
        return {"account_id": ACCOUNT_ID, "cash_balance": str(start), "collected_data_deleted": False}

    def _daily_state(self, session: Session, account: RegimePaperAccount | None, *, create: bool) -> RegimeDailyRiskState | None:
        date = utc_now().date().isoformat()
        row = session.scalar(select(RegimeDailyRiskState).where(RegimeDailyRiskState.account_id == ACCOUNT_ID, RegimeDailyRiskState.utc_date == date))
        if row is None and create and account is not None:
            row = RegimeDailyRiskState(account_id=ACCOUNT_ID, utc_date=date, starting_equity=self._equity(account, self._open_positions(session)))
            session.add(row)
            session.flush()
        return row

    def _symbol_state(self, session: Session, symbol: str, utc_date: str, *, create: bool) -> RegimeSymbolRiskState:
        row = session.scalar(select(RegimeSymbolRiskState).where(RegimeSymbolRiskState.account_id == ACCOUNT_ID, RegimeSymbolRiskState.symbol == symbol, RegimeSymbolRiskState.utc_date == utc_date))
        if row is None and create:
            row = RegimeSymbolRiskState(account_id=ACCOUNT_ID, symbol=symbol, utc_date=utc_date)
            session.add(row)
            session.flush()
        return row

    def _open_positions(self, session: Session) -> list[Position]:
        return list(session.scalars(select(Position).where(Position.paper_account_id == ACCOUNT_ID, Position.status == "OPEN")).all())

    def _equity(self, account: RegimePaperAccount, positions: list[Position]) -> Decimal:
        return dec(account.cash_balance) + sum((dec(p.unrealized_pnl) for p in positions), Decimal("0"))

    def _snapshot_equity(self, session: Session, account: RegimePaperAccount) -> None:
        positions = self._open_positions(session)
        unrealized = sum((dec(p.unrealized_pnl) for p in positions), Decimal("0"))
        equity = dec(account.cash_balance) + unrealized
        session.add(AccountEquity(
            timestamp=utc_now(),
            paper_account_id=ACCOUNT_ID,
            cash_balance=float(account.cash_balance),
            equity=float(equity),
            realized_pnl=float(account.realized_trading_pnl),
            unrealized_pnl=float(unrealized),
            drawdown=float(max(dec(account.starting_balance) - equity, Decimal("0"))),
            raw={"strategy": STRATEGY_NAME, "fees": str(account.total_fees), "paper_only": True},
        ))

    def _mirror_decision(self, session: Session, row: RegimeDecisionRecord) -> None:
        session.add(AiDecision(
            symbol=row.symbol,
            strategy_name=STRATEGY_NAME,
            source_name=STRATEGY_VERSION,
            feature_schema_version=FEATURE_SCHEMA_VERSION,
            action=row.action,
            confidence=row.confidence,
            reason=",".join(row.rejection_codes or []) or row.entry_reason or row.exit_reason,
            execution_status="FILLED" if row.paper_order_id else "RECORDED",
            execution_message="paper-only deterministic ledger",
            market_state=row.indicator_values,
            result={"decision_record_id": row.id, "paper_order_id": row.paper_order_id, "shadow": row.shadow_decision},
            raw_payload={"strategy_version": STRATEGY_VERSION, "candle_close_time": row.candle_close_time.isoformat()},
            created_at=row.decision_time,
        ))

    def _mirror_trade(self, session: Session, position: Position, order: RegimePaperOrder, account: RegimePaperAccount, *, realized: Decimal) -> None:
        equity = self._equity(account, self._open_positions(session))
        session.add(PaperTrade(
            symbol=order.symbol,
            paper_account_id=ACCOUNT_ID,
            simulated_order_id=order.client_order_id,
            action=order.order_side,
            side=order.position_side,
            quantity=float(order.quantity),
            price=float(order.fill_price),
            notional=float(order.notional),
            fee=float(order.fee),
            realized_pnl=float(realized),  # opening fills always pass Decimal(0)
            balance_after=float(account.cash_balance),
            equity_after=float(equity),
            status="FILLED",
            reason=order.reason_code,
            raw_payload={"entry_fee": float(order.fee) if order.is_entry else 0.0, "exit_fee": float(order.fee) if not order.is_entry else 0.0, "realized_trading_pnl": float(realized), "paper_only": True},
        ))

    def _account_summary(self, account: RegimePaperAccount, positions: list[Position]) -> dict[str, Any]:
        unrealized = sum((dec(p.unrealized_pnl) for p in positions), Decimal("0"))
        return {
            "account_id": account.account_id,
            "cash": str(account.cash_balance),
            "unrealized_pnl": str(unrealized),
            "equity": str(dec(account.cash_balance) + unrealized),
            "realized_trading_pnl": str(account.realized_trading_pnl),
            "total_fees": str(account.total_fees),
            "funding_cost": str(account.funding_cost),
            "administrative_shutdown": account.administrative_shutdown,
        }

    def _position_summary(self, session: Session, position: Position) -> dict[str, Any]:
        meta = session.scalar(select(RegimePositionMeta).where(RegimePositionMeta.position_id == position.id))
        risk = dec(meta.initial_risk_per_unit) * dec(position.quantity) if meta else Decimal("0")
        account = session.get(RegimePaperAccount, ACCOUNT_ID)
        equity = self._equity(account, self._open_positions(session)) if account else Decimal("0")
        return {
            "position_id": position.id,
            "symbol": position.symbol,
            "side": position.side,
            "quantity": str(position.quantity),
            "entry_price": str(position.entry_price),
            "stop_loss": str(position.stop_loss),
            "take_profit": str(position.take_profit),
            "unrealized_pnl": str(position.unrealized_pnl),
            "risk_dollars": str(risk),
            "risk_percent": str((risk / equity * Decimal("100")) if equity else Decimal("0")),
            "entry_fee": str(meta.entry_fee) if meta else "0",
            "exit_fee": str(meta.exit_fee) if meta else "0",
            "total_costs": str(meta.total_costs) if meta else "0",
            "bars_held": meta.bars_held if meta else 0,
            "break_even_active": meta.break_even_active if meta else False,
            "trailing_active": meta.trailing_active if meta else False,
        }

    def _decision_summary(self, row: RegimeDecisionRecord) -> dict[str, Any]:
        return {
            "decision_id": row.id,
            "symbol": row.symbol,
            "candle_close_time": row.candle_close_time.isoformat(),
            "regime": row.regime,
            "action": row.action,
            "confidence": row.confidence,
            "confidence_components": row.confidence_components or {},
            "reason_codes": row.rejection_codes or [],
            "shadow_decision": row.shadow_decision,
            "data_fresh": row.data_fresh,
            "spread_bps": str(row.spread_bps) if row.spread_bps is not None else None,
            "spread_estimated": row.spread_estimated,
            "paper_order_id": row.paper_order_id,
            "position_id": row.position_id,
        }

    def _daily_summary(self, row: RegimeDailyRiskState) -> dict[str, Any]:
        limit = dec(row.starting_equity) * self.config.daily_loss_limit_pct
        net_loss = max(-(dec(row.realized_trading_pnl) - dec(row.total_fees)), Decimal("0"))
        return {
            "utc_date": row.utc_date,
            "starting_equity": str(row.starting_equity),
            "net_pnl_after_fees": str(dec(row.realized_trading_pnl) - dec(row.total_fees)),
            "loss_limit": str(limit),
            "loss_limit_usage_pct": str((net_loss / limit * Decimal("100")) if limit else Decimal("0")),
            "new_trades": row.new_trades,
            "consecutive_losses": row.consecutive_losses,
            "circuit_breaker": row.circuit_breaker,
        }

    @staticmethod
    def _stable_id(*parts: str) -> str:
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:48]
