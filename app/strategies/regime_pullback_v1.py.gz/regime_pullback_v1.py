from __future__ import annotations

"""Pure, point-in-time logic for the conservative paper-only strategy.

The module intentionally contains no exchange client and no network code.  Currency
and quantity calculations use :class:`decimal.Decimal`; indicator math uses float
because it is descriptive market data rather than accounting state.
"""

from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_DOWN, getcontext
from enum import StrEnum
from math import isfinite
from statistics import median
from typing import Any, Iterable, Sequence

getcontext().prec = 38

STRATEGY_NAME = "regime_pullback_v1"
STRATEGY_VERSION = "regime_pullback_v1.0.0"
FEATURE_SCHEMA_VERSION = "regime-pullback-features-v1"


class Regime(StrEnum):
    LONG = "LONG"
    SHORT = "SHORT"
    NEUTRAL = "NEUTRAL"


class DecisionAction(StrEnum):
    ENTER_LONG = "ENTER_LONG"
    ENTER_SHORT = "ENTER_SHORT"
    HOLD = "HOLD"
    EXIT_LONG = "EXIT_LONG"
    EXIT_SHORT = "EXIT_SHORT"
    REJECTED_LONG = "REJECTED_LONG"
    REJECTED_SHORT = "REJECTED_SHORT"


class ReasonCode(StrEnum):
    REGIME_NEUTRAL = "REGIME_NEUTRAL"
    ADX_TOO_LOW = "ADX_TOO_LOW"
    NO_PULLBACK = "NO_PULLBACK"
    RSI_NOT_CONFIRMED = "RSI_NOT_CONFIRMED"
    BREAKOUT_NOT_CONFIRMED = "BREAKOUT_NOT_CONFIRMED"
    VOLUME_TOO_LOW = "VOLUME_TOO_LOW"
    SPREAD_TOO_WIDE = "SPREAD_TOO_WIDE"
    ATR_TOO_LOW = "ATR_TOO_LOW"
    ATR_TOO_HIGH = "ATR_TOO_HIGH"
    DATA_STALE = "DATA_STALE"
    DATA_MISSING = "DATA_MISSING"
    CANDLE_STILL_FORMING = "CANDLE_STILL_FORMING"
    FUNDING_TOO_EXTREME = "FUNDING_TOO_EXTREME"
    CONFIDENCE_TOO_LOW = "CONFIDENCE_TOO_LOW"
    COOLDOWN_ACTIVE = "COOLDOWN_ACTIVE"
    DAILY_TRADE_LIMIT = "DAILY_TRADE_LIMIT"
    PORTFOLIO_DAILY_TRADE_LIMIT = "PORTFOLIO_DAILY_TRADE_LIMIT"
    DAILY_LOSS_LIMIT = "DAILY_LOSS_LIMIT"
    CONSECUTIVE_LOSS_LIMIT = "CONSECUTIVE_LOSS_LIMIT"
    MAX_EXPOSURE = "MAX_EXPOSURE"
    MAX_OPEN_POSITIONS = "MAX_OPEN_POSITIONS"
    DUPLICATE_DECISION = "DUPLICATE_DECISION"
    DUPLICATE_ORDER = "DUPLICATE_ORDER"
    DUPLICATE_FILL = "DUPLICATE_FILL"
    POSITION_ALREADY_OPEN = "POSITION_ALREADY_OPEN"
    QUANTITY_TOO_SMALL = "QUANTITY_TOO_SMALL"
    INVALID_STOP_DISTANCE = "INVALID_STOP_DISTANCE"
    COMPONENT_UNHEALTHY = "COMPONENT_UNHEALTHY"
    PAPER_ONLY_REQUIRED = "PAPER_ONLY_REQUIRED"
    STOP_LOSS = "STOP_LOSS"
    TAKE_PROFIT = "TAKE_PROFIT"
    BREAK_EVEN = "BREAK_EVEN"
    TRAILING_STOP = "TRAILING_STOP"
    TIME_EXIT = "TIME_EXIT"
    REGIME_FLIP = "REGIME_FLIP"
    DAILY_CIRCUIT_BREAKER = "DAILY_CIRCUIT_BREAKER"
    STALE_DATA_TIMEOUT = "STALE_DATA_TIMEOUT"
    ADMIN_SHUTDOWN = "ADMIN_SHUTDOWN"


def dec(value: Decimal | float | int | str) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def ensure_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


@dataclass(frozen=True)
class CandleBar:
    open_time: datetime
    close_time: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    source_timestamps: tuple[str, ...] = ()
    complete: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(self, "open_time", ensure_utc(self.open_time))
        object.__setattr__(self, "close_time", ensure_utc(self.close_time))


@dataclass(frozen=True)
class DerivativesSnapshot:
    open_interest_change: float | None = None
    funding_rate: float | None = None
    taker_imbalance: float | None = None
    timestamp: datetime | None = None


@dataclass(frozen=True)
class FeatureSnapshot:
    symbol: str
    decision_time: datetime
    candle_close_time: datetime
    feature_time: datetime
    market_data_time: datetime
    source_timestamps: dict[str, str]
    data_fresh: bool
    data_complete: bool
    candle_complete: bool
    missing_intervals: bool
    close: float
    high: float
    low: float
    volume: float
    previous_high: float
    previous_low: float
    previous_close: float
    ema20: float
    current_low: float
    current_high: float
    previous_low_15m: float
    previous_high_15m: float
    rsi14: float
    previous_rsi14: float
    atr15m: float
    median_volume20: float
    regime: Regime
    ema50_1h: float
    ema200_1h: float
    ema50_1h_three_bars_ago: float
    adx14_1h: float
    close_1h: float
    bid: float | None = None
    ask: float | None = None
    spread_bps: float = 4.0
    spread_estimated: bool = True
    spread_method: str = "fixed_conservative_estimate"
    derivatives: DerivativesSnapshot = field(default_factory=DerivativesSnapshot)

    def as_payload(self) -> dict[str, Any]:
        def json_safe(value: Any) -> Any:
            if isinstance(value, datetime):
                return ensure_utc(value).isoformat()
            if isinstance(value, Decimal):
                return str(value)
            if isinstance(value, StrEnum):
                return value.value
            if isinstance(value, dict):
                return {str(key): json_safe(item) for key, item in value.items()}
            if isinstance(value, (list, tuple)):
                return [json_safe(item) for item in value]
            return value

        result = json_safe(asdict(self))
        result["regime"] = self.regime.value
        return result


@dataclass(frozen=True)
class StrategyConfig:
    fixed_leverage: Decimal = Decimal("1")
    risk_per_trade_pct: Decimal = Decimal("0.0025")
    max_symbol_exposure_pct: Decimal = Decimal("0.10")
    max_total_exposure_pct: Decimal = Decimal("0.20")
    max_open_positions: int = 2
    max_positions_per_symbol: int = 1
    max_trades_per_symbol_per_day: int = 3
    max_total_trades_per_day: int = 8
    daily_loss_limit_pct: Decimal = Decimal("0.01")
    max_consecutive_losses: int = 3
    cooldown_bars: int = 8
    min_confidence: float = 0.75
    adx_min: float = 20.0
    atr_pct_min: float = 0.0025
    atr_pct_max: float = 0.03
    max_spread_bps: float = 8.0
    max_abs_funding_rate: float = 0.0005
    atr_stop_multiplier: Decimal = Decimal("1.5")
    atr_take_profit_multiplier: Decimal = Decimal("2.5")
    trailing_atr_multiplier: Decimal = Decimal("1")
    break_even_at_r: Decimal = Decimal("1")
    trailing_start_at_r: Decimal = Decimal("1.5")
    time_exit_bars: int = 16
    time_exit_min_r: Decimal = Decimal("0.5")
    fee_rate_per_side: Decimal = Decimal("0.0004")
    slippage_rate_per_side: Decimal = Decimal("0.0002")
    estimated_spread_bps: Decimal = Decimal("4")
    stale_exit_timeout_minutes: int = 60
    min_quantity: Decimal = Decimal("0.000001")
    quantity_step: Decimal = Decimal("0.000001")
    min_notional: Decimal = Decimal("5")


@dataclass(frozen=True)
class RiskContext:
    paper_equity: Decimal
    paper_cash: Decimal
    current_total_open_notional: Decimal = Decimal("0")
    open_positions: int = 0
    symbol_has_position: bool = False
    symbol_trades_today: int = 0
    portfolio_trades_today: int = 0
    starting_day_equity: Decimal = Decimal("0")
    day_net_pnl: Decimal = Decimal("0")
    consecutive_losses: int = 0
    cooldown_active: bool = False
    components_healthy: bool = True
    duplicate_decision: bool = False
    duplicate_order: bool = False
    leverage_requested: Decimal = Decimal("1")


@dataclass(frozen=True)
class ConfidenceBreakdown:
    regime_alignment: float
    adx_trend_strength: float
    pullback_reclaim_quality: float
    rsi_confirmation: float
    breakout_confirmation: float
    volume_confirmation: float
    derivatives_confirmation: float
    total: float

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class QuantityResult:
    requested_quantity: Decimal
    approved_quantity: Decimal
    risk_budget: Decimal
    stop_distance: Decimal
    estimated_notional: Decimal
    rejection_code: ReasonCode | None = None


@dataclass(frozen=True)
class StrategyEvaluation:
    action: DecisionAction
    regime: Regime
    confidence: float
    confidence_components: ConfidenceBreakdown
    reason_codes: tuple[ReasonCode, ...]
    strategy_conditions_passed: bool
    risk_approved: bool
    shadow_decision: bool
    quantity: QuantityResult | None = None
    entry_price_reference: Decimal | None = None
    stop_price: Decimal | None = None
    target_price: Decimal | None = None


@dataclass
class PositionState:
    position_id: str
    symbol: str
    side: str
    quantity: Decimal
    entry_price: Decimal
    initial_stop_distance: Decimal
    stop_price: Decimal
    target_price: Decimal
    atr_at_entry: Decimal
    opened_at: datetime
    bars_held: int = 0
    max_favorable_r: Decimal = Decimal("0")
    entry_fee: Decimal = Decimal("0")
    exit_fee: Decimal = Decimal("0")
    stale_since: datetime | None = None
    trailing_active: bool = False
    break_even_active: bool = False


@dataclass(frozen=True)
class ExitEvaluation:
    should_exit: bool
    action: DecisionAction | None
    reason_code: ReasonCode | None
    exit_reference_price: Decimal | None
    updated_stop_price: Decimal
    max_favorable_r: Decimal
    trailing_active: bool
    break_even_active: bool


@dataclass(frozen=True)
class FutureLabel:
    available: bool
    horizon_minutes: int
    future_return: float | None = None
    future_return_after_costs: float | None = None
    maximum_favorable_excursion: float | None = None
    maximum_adverse_excursion: float | None = None
    stop_reached_first: bool | None = None
    target_reached_first: bool | None = None
    time_to_stop_seconds: int | None = None
    time_to_target_seconds: int | None = None
    data_complete: bool = False


def floor_time(value: datetime, minutes: int) -> datetime:
    value = ensure_utc(value)
    epoch = int(value.timestamp())
    seconds = minutes * 60
    return datetime.fromtimestamp((epoch // seconds) * seconds, tz=timezone.utc)


def latest_completed_close(now: datetime, minutes: int) -> datetime:
    return floor_time(now, minutes)


def resample_complete_bars(one_minute_bars: Sequence[CandleBar], minutes: int) -> list[CandleBar]:
    """Resample only exact, contiguous, completed groups.

    Incomplete buckets are deliberately omitted so they cannot leak into a decision.
    """

    if minutes <= 0:
        raise ValueError("minutes must be positive")
    groups: dict[datetime, list[CandleBar]] = {}
    for bar in sorted(one_minute_bars, key=lambda item: item.open_time):
        if not bar.complete:
            continue
        bucket = floor_time(bar.open_time, minutes)
        groups.setdefault(bucket, []).append(bar)
    result: list[CandleBar] = []
    expected_delta = timedelta(minutes=1)
    for bucket, bars in sorted(groups.items()):
        if len(bars) != minutes:
            continue
        bars = sorted(bars, key=lambda item: item.open_time)
        contiguous = all(bars[index].open_time - bars[index - 1].open_time == expected_delta for index in range(1, len(bars)))
        expected_close = bucket + timedelta(minutes=minutes)
        # Binance commonly reports the final 1m close at xx:xx:59.999 rather than
        # the next exact minute. Open-time contiguity plus completed flags are the
        # authoritative interval check; normalize the aggregate close timestamp.
        final_close_delta = abs((bars[-1].close_time - expected_close).total_seconds())
        if not contiguous or final_close_delta > 1.0:
            continue
        result.append(
            CandleBar(
                open_time=bucket,
                close_time=expected_close,
                open=bars[0].open,
                high=max(item.high for item in bars),
                low=min(item.low for item in bars),
                close=bars[-1].close,
                volume=sum(item.volume for item in bars),
                source_timestamps=tuple(item.close_time.isoformat() for item in bars),
                complete=True,
            )
        )
    return result


def point_in_time_bars(bars: Sequence[CandleBar], decision_close: datetime) -> list[CandleBar]:
    decision_close = ensure_utc(decision_close)
    return [bar for bar in bars if bar.complete and bar.close_time <= decision_close]


def ema(values: Sequence[float], period: int) -> list[float]:
    if period <= 0 or len(values) < period:
        raise ValueError("insufficient values for EMA")
    seed = sum(values[:period]) / period
    output = [float("nan")] * (period - 1) + [seed]
    multiplier = 2.0 / (period + 1.0)
    current = seed
    for value in values[period:]:
        current = (value - current) * multiplier + current
        output.append(current)
    return output


def rsi(values: Sequence[float], period: int = 14) -> list[float]:
    if len(values) < period + 1:
        raise ValueError("insufficient values for RSI")
    gains: list[float] = []
    losses: list[float] = []
    for previous, current in zip(values, values[1:]):
        change = current - previous
        gains.append(max(change, 0.0))
        losses.append(max(-change, 0.0))
    average_gain = sum(gains[:period]) / period
    average_loss = sum(losses[:period]) / period
    output = [float("nan")] * period

    def score(gain: float, loss: float) -> float:
        if loss == 0:
            return 100.0
        relative_strength = gain / loss
        return 100.0 - (100.0 / (1.0 + relative_strength))

    output.append(score(average_gain, average_loss))
    for gain, loss in zip(gains[period:], losses[period:]):
        average_gain = ((average_gain * (period - 1)) + gain) / period
        average_loss = ((average_loss * (period - 1)) + loss) / period
        output.append(score(average_gain, average_loss))
    return output


def true_ranges(bars: Sequence[CandleBar]) -> list[float]:
    if len(bars) < 2:
        return []
    result: list[float] = []
    previous_close = bars[0].close
    for bar in bars[1:]:
        result.append(max(bar.high - bar.low, abs(bar.high - previous_close), abs(bar.low - previous_close)))
        previous_close = bar.close
    return result


def atr(bars: Sequence[CandleBar], period: int = 14) -> list[float]:
    ranges = true_ranges(bars)
    if len(ranges) < period:
        raise ValueError("insufficient values for ATR")
    current = sum(ranges[:period]) / period
    output = [float("nan")] * period + [current]
    for value in ranges[period:]:
        current = ((current * (period - 1)) + value) / period
        output.append(current)
    return output


def adx(bars: Sequence[CandleBar], period: int = 14) -> list[float]:
    if len(bars) < (period * 2) + 1:
        raise ValueError("insufficient values for ADX")
    trs: list[float] = []
    plus_dm: list[float] = []
    minus_dm: list[float] = []
    for previous, current in zip(bars, bars[1:]):
        up_move = current.high - previous.high
        down_move = previous.low - current.low
        plus_dm.append(up_move if up_move > down_move and up_move > 0 else 0.0)
        minus_dm.append(down_move if down_move > up_move and down_move > 0 else 0.0)
        trs.append(max(current.high - current.low, abs(current.high - previous.close), abs(current.low - previous.close)))
    smoothed_tr = sum(trs[:period])
    smoothed_plus = sum(plus_dm[:period])
    smoothed_minus = sum(minus_dm[:period])
    dx_values: list[float] = []
    for index in range(period, len(trs) + 1):
        if index > period:
            source = index - 1
            smoothed_tr = smoothed_tr - (smoothed_tr / period) + trs[source]
            smoothed_plus = smoothed_plus - (smoothed_plus / period) + plus_dm[source]
            smoothed_minus = smoothed_minus - (smoothed_minus / period) + minus_dm[source]
        plus_di = 100.0 * smoothed_plus / smoothed_tr if smoothed_tr else 0.0
        minus_di = 100.0 * smoothed_minus / smoothed_tr if smoothed_tr else 0.0
        denominator = plus_di + minus_di
        dx_values.append(100.0 * abs(plus_di - minus_di) / denominator if denominator else 0.0)
    if len(dx_values) < period:
        raise ValueError("insufficient DX values for ADX")
    current_adx = sum(dx_values[:period]) / period
    prefix = len(bars) - len(dx_values)
    output = [float("nan")] * (prefix + period - 1) + [current_adx]
    for value in dx_values[period:]:
        current_adx = ((current_adx * (period - 1)) + value) / period
        output.append(current_adx)
    return output


def classify_regime(
    *,
    close_1h: float,
    ema50_1h: float,
    ema200_1h: float,
    ema50_three_bars_ago: float,
    adx14_1h: float,
    adx_min: float = 20.0,
) -> Regime:
    if not all(isfinite(value) for value in (close_1h, ema50_1h, ema200_1h, ema50_three_bars_ago, adx14_1h)):
        return Regime.NEUTRAL
    if adx14_1h < adx_min:
        return Regime.NEUTRAL
    if close_1h > ema200_1h and ema50_1h > ema200_1h and ema50_1h > ema50_three_bars_ago:
        return Regime.LONG
    if close_1h < ema200_1h and ema50_1h < ema200_1h and ema50_1h < ema50_three_bars_ago:
        return Regime.SHORT
    return Regime.NEUTRAL


def build_feature_snapshot(
    *,
    symbol: str,
    decision_close: datetime,
    bars_15m: Sequence[CandleBar],
    bars_1h: Sequence[CandleBar],
    now: datetime | None = None,
    bid: float | None = None,
    ask: float | None = None,
    derivatives: DerivativesSnapshot | None = None,
    max_data_age_intervals: int = 2,
) -> FeatureSnapshot:
    now = ensure_utc(now or utc_now())
    decision_close = ensure_utc(decision_close)
    pt15 = point_in_time_bars(bars_15m, decision_close)
    pt1h = point_in_time_bars(bars_1h, decision_close)
    if len(pt15) < 35 or len(pt1h) < 205:
        raise ValueError("insufficient completed candles")
    latest15, previous15 = pt15[-1], pt15[-2]
    latest1h = pt1h[-1]
    ema20_series = ema([bar.close for bar in pt15], 20)
    rsi_series = rsi([bar.close for bar in pt15], 14)
    atr15_series = atr(pt15, 14)
    ema50_series = ema([bar.close for bar in pt1h], 50)
    ema200_series = ema([bar.close for bar in pt1h], 200)
    adx_series = adx(pt1h, 14)
    regime = classify_regime(
        close_1h=latest1h.close,
        ema50_1h=ema50_series[-1],
        ema200_1h=ema200_series[-1],
        ema50_three_bars_ago=ema50_series[-4],
        adx14_1h=adx_series[-1],
    )
    market_data_time = latest15.close_time
    age = now - market_data_time
    data_fresh = age <= timedelta(minutes=15 * max_data_age_intervals)
    spread_estimated = bid is None or ask is None or bid <= 0 or ask <= bid
    if spread_estimated:
        spread_bps = 4.0
        spread_method = "fixed_conservative_estimate"
        bid = None
        ask = None
    else:
        mid = (bid + ask) / 2.0
        spread_bps = ((ask - bid) / mid) * 10_000.0
        spread_method = "measured_bid_ask"
    volume_window = [bar.volume for bar in pt15[-21:-1]]
    source_timestamps = {
        "decision_15m": latest15.close_time.isoformat(),
        "regime_1h": latest1h.close_time.isoformat(),
        "oldest_ema200_1h": pt1h[-200].close_time.isoformat(),
    }
    derivative_snapshot = derivatives or DerivativesSnapshot()
    if derivative_snapshot.timestamp is not None:
        source_timestamps["derivatives"] = ensure_utc(derivative_snapshot.timestamp).isoformat()
    return FeatureSnapshot(
        symbol=symbol.upper(),
        decision_time=now,
        candle_close_time=latest15.close_time,
        feature_time=now,
        market_data_time=market_data_time,
        source_timestamps=source_timestamps,
        data_fresh=data_fresh,
        data_complete=True,
        candle_complete=latest15.complete and latest15.close_time <= decision_close,
        missing_intervals=False,
        close=latest15.close,
        high=latest15.high,
        low=latest15.low,
        volume=latest15.volume,
        previous_high=previous15.high,
        previous_low=previous15.low,
        previous_close=previous15.close,
        ema20=ema20_series[-1],
        current_low=latest15.low,
        current_high=latest15.high,
        previous_low_15m=previous15.low,
        previous_high_15m=previous15.high,
        rsi14=rsi_series[-1],
        previous_rsi14=rsi_series[-2],
        atr15m=atr15_series[-1],
        median_volume20=float(median(volume_window)),
        regime=regime,
        ema50_1h=ema50_series[-1],
        ema200_1h=ema200_series[-1],
        ema50_1h_three_bars_ago=ema50_series[-4],
        adx14_1h=adx_series[-1],
        close_1h=latest1h.close,
        bid=bid,
        ask=ask,
        spread_bps=spread_bps,
        spread_estimated=spread_estimated,
        spread_method=spread_method,
        derivatives=derivative_snapshot,
    )


def confidence_breakdown(feature: FeatureSnapshot) -> ConfidenceBreakdown:
    regime_score = 1.0 if feature.regime in {Regime.LONG, Regime.SHORT} else 0.0
    adx_score = clamp(0.5 + max(feature.adx14_1h - 20.0, 0.0) / 40.0, 0.0, 1.0)
    atr_value = max(feature.atr15m, 1e-12)
    if feature.regime == Regime.LONG:
        reclaim_distance = max(feature.close - feature.ema20, 0.0)
        rsi_distance = max(feature.rsi14 - 50.0, 0.0)
        breakout_distance = max(feature.close - feature.previous_high, 0.0)
    else:
        reclaim_distance = max(feature.ema20 - feature.close, 0.0)
        rsi_distance = max(50.0 - feature.rsi14, 0.0)
        breakout_distance = max(feature.previous_low - feature.close, 0.0)
    pullback_score = clamp(0.8 + 0.2 * min(reclaim_distance / atr_value, 1.0))
    rsi_score = clamp(0.8 + 0.2 * min(rsi_distance / 10.0, 1.0))
    breakout_score = clamp(0.8 + 0.2 * min(breakout_distance / atr_value, 1.0))
    volume_ratio = feature.volume / max(feature.median_volume20, 1e-12)
    volume_score = clamp(0.8 + 0.2 * min(max(volume_ratio - 1.0, 0.0), 1.0))

    available: list[float] = []
    derivatives = feature.derivatives
    if derivatives.open_interest_change is not None:
        aligned = derivatives.open_interest_change > 0
        available.append(1.0 if aligned else 0.0)
    if derivatives.funding_rate is not None:
        # Mild/neutral funding is preferable.  Extreme funding is a hard filter elsewhere.
        available.append(clamp(1.0 - abs(derivatives.funding_rate) / 0.0005))
    if derivatives.taker_imbalance is not None:
        aligned = derivatives.taker_imbalance > 0 if feature.regime == Regime.LONG else derivatives.taker_imbalance < 0
        available.append(1.0 if aligned else 0.0)
    derivatives_score = sum(available) / len(available) if available else 0.0
    total = (
        0.25 * regime_score
        + 0.15 * adx_score
        + 0.20 * pullback_score
        + 0.15 * rsi_score
        + 0.10 * breakout_score
        + 0.10 * volume_score
        + 0.05 * derivatives_score
    )
    return ConfidenceBreakdown(
        regime_alignment=regime_score,
        adx_trend_strength=adx_score,
        pullback_reclaim_quality=pullback_score,
        rsi_confirmation=rsi_score,
        breakout_confirmation=breakout_score,
        volume_confirmation=volume_score,
        derivatives_confirmation=derivatives_score,
        total=round(clamp(total), 8),
    )


def _entry_condition_reasons(feature: FeatureSnapshot, config: StrategyConfig) -> list[ReasonCode]:
    reasons: list[ReasonCode] = []
    if feature.regime == Regime.NEUTRAL:
        reasons.append(ReasonCode.REGIME_NEUTRAL)
        return reasons
    if feature.adx14_1h < config.adx_min:
        reasons.append(ReasonCode.ADX_TOO_LOW)
    current_or_previous_touched = False
    if feature.regime == Regime.LONG:
        current_or_previous_touched = feature.current_low <= feature.ema20 or feature.previous_low_15m <= feature.ema20
        if not current_or_previous_touched or feature.close <= feature.ema20:
            reasons.append(ReasonCode.NO_PULLBACK)
        if not (feature.previous_rsi14 <= 50.0 and feature.rsi14 > 50.0):
            reasons.append(ReasonCode.RSI_NOT_CONFIRMED)
        if feature.close <= feature.previous_high:
            reasons.append(ReasonCode.BREAKOUT_NOT_CONFIRMED)
    else:
        current_or_previous_touched = feature.current_high >= feature.ema20 or feature.previous_high_15m >= feature.ema20
        if not current_or_previous_touched or feature.close >= feature.ema20:
            reasons.append(ReasonCode.NO_PULLBACK)
        if not (feature.previous_rsi14 >= 50.0 and feature.rsi14 < 50.0):
            reasons.append(ReasonCode.RSI_NOT_CONFIRMED)
        if feature.close >= feature.previous_low:
            reasons.append(ReasonCode.BREAKOUT_NOT_CONFIRMED)
    if feature.volume < feature.median_volume20:
        reasons.append(ReasonCode.VOLUME_TOO_LOW)
    return reasons


def _data_and_market_reasons(feature: FeatureSnapshot, config: StrategyConfig) -> list[ReasonCode]:
    reasons: list[ReasonCode] = []
    if not feature.candle_complete:
        reasons.append(ReasonCode.CANDLE_STILL_FORMING)
    if feature.missing_intervals or not feature.data_complete:
        reasons.append(ReasonCode.DATA_MISSING)
    if not feature.data_fresh:
        reasons.append(ReasonCode.DATA_STALE)
    if feature.spread_bps > config.max_spread_bps:
        reasons.append(ReasonCode.SPREAD_TOO_WIDE)
    if feature.close <= 0 or feature.atr15m <= 0:
        reasons.append(ReasonCode.DATA_MISSING)
    else:
        atr_pct = feature.atr15m / feature.close
        if atr_pct < config.atr_pct_min:
            reasons.append(ReasonCode.ATR_TOO_LOW)
        if atr_pct > config.atr_pct_max:
            reasons.append(ReasonCode.ATR_TOO_HIGH)
    funding = feature.derivatives.funding_rate
    if funding is not None and abs(funding) > config.max_abs_funding_rate:
        reasons.append(ReasonCode.FUNDING_TOO_EXTREME)
    return reasons


def _risk_reasons(context: RiskContext, config: StrategyConfig) -> list[ReasonCode]:
    reasons: list[ReasonCode] = []
    if context.duplicate_decision:
        reasons.append(ReasonCode.DUPLICATE_DECISION)
    if context.duplicate_order:
        reasons.append(ReasonCode.DUPLICATE_ORDER)
    if not context.components_healthy:
        reasons.append(ReasonCode.COMPONENT_UNHEALTHY)
    if context.leverage_requested != Decimal("1"):
        reasons.append(ReasonCode.PAPER_ONLY_REQUIRED)
    if context.symbol_has_position:
        reasons.append(ReasonCode.POSITION_ALREADY_OPEN)
    if context.open_positions >= config.max_open_positions:
        reasons.append(ReasonCode.MAX_OPEN_POSITIONS)
    if context.current_total_open_notional >= context.paper_equity * config.max_total_exposure_pct:
        reasons.append(ReasonCode.MAX_EXPOSURE)
    if context.cooldown_active:
        reasons.append(ReasonCode.COOLDOWN_ACTIVE)
    if context.symbol_trades_today >= config.max_trades_per_symbol_per_day:
        reasons.append(ReasonCode.DAILY_TRADE_LIMIT)
    if context.portfolio_trades_today >= config.max_total_trades_per_day:
        reasons.append(ReasonCode.PORTFOLIO_DAILY_TRADE_LIMIT)
    start_equity = context.starting_day_equity or context.paper_equity
    if start_equity > 0 and context.day_net_pnl <= -(start_equity * config.daily_loss_limit_pct):
        reasons.append(ReasonCode.DAILY_LOSS_LIMIT)
    if context.consecutive_losses >= config.max_consecutive_losses:
        reasons.append(ReasonCode.CONSECUTIVE_LOSS_LIMIT)
    return reasons


def round_down_quantity(quantity: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError("quantity step must be positive")
    return (quantity / step).to_integral_value(rounding=ROUND_DOWN) * step


def calculate_quantity(
    *,
    entry_price: Decimal,
    atr_value: Decimal,
    context: RiskContext,
    config: StrategyConfig,
) -> QuantityResult:
    stop_distance = max(config.atr_stop_multiplier * atr_value, entry_price * Decimal("0.004"))
    risk_budget = context.paper_equity * config.risk_per_trade_pct
    if stop_distance <= 0 or not stop_distance.is_finite():
        return QuantityResult(Decimal("0"), Decimal("0"), risk_budget, stop_distance, Decimal("0"), ReasonCode.INVALID_STOP_DISTANCE)
    requested = risk_budget / stop_distance
    symbol_cap_qty = (context.paper_equity * config.max_symbol_exposure_pct) / entry_price
    total_headroom = max(context.paper_equity * config.max_total_exposure_pct - context.current_total_open_notional, Decimal("0"))
    total_cap_qty = total_headroom / entry_price
    available_cash_qty = max(context.paper_cash, Decimal("0")) / entry_price
    approved = min(requested, symbol_cap_qty, total_cap_qty, available_cash_qty)
    approved = round_down_quantity(approved, config.quantity_step)
    notional = approved * entry_price
    if approved < config.min_quantity or notional < config.min_notional:
        return QuantityResult(requested, Decimal("0"), risk_budget, stop_distance, notional, ReasonCode.QUANTITY_TOO_SMALL)
    return QuantityResult(requested, approved, risk_budget, stop_distance, notional, None)


def reference_entry_price(feature: FeatureSnapshot, side: str, config: StrategyConfig) -> Decimal:
    close = dec(feature.close)
    if feature.bid is not None and feature.ask is not None and feature.ask > feature.bid > 0:
        reference = dec(feature.ask if side == "LONG" else feature.bid)
    else:
        half_spread = dec(feature.spread_bps) / Decimal("20000")
        reference = close * (Decimal("1") + half_spread if side == "LONG" else Decimal("1") - half_spread)
    return reference


def paper_fill_price(reference_price: Decimal, order_side: str, config: StrategyConfig) -> Decimal:
    if order_side.upper() == "BUY":
        return reference_price * (Decimal("1") + config.slippage_rate_per_side)
    if order_side.upper() == "SELL":
        return reference_price * (Decimal("1") - config.slippage_rate_per_side)
    raise ValueError("order_side must be BUY or SELL")


def evaluate_entry(feature: FeatureSnapshot, context: RiskContext, config: StrategyConfig | None = None) -> StrategyEvaluation:
    config = config or StrategyConfig()
    blank = ConfidenceBreakdown(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    if feature.regime == Regime.NEUTRAL:
        return StrategyEvaluation(
            action=DecisionAction.HOLD,
            regime=feature.regime,
            confidence=0.0,
            confidence_components=blank,
            reason_codes=(ReasonCode.REGIME_NEUTRAL,),
            strategy_conditions_passed=False,
            risk_approved=False,
            shadow_decision=False,
        )
    rejected_action = DecisionAction.REJECTED_LONG if feature.regime == Regime.LONG else DecisionAction.REJECTED_SHORT
    reasons = _data_and_market_reasons(feature, config)
    reasons.extend(_entry_condition_reasons(feature, config))
    components = confidence_breakdown(feature)
    if components.total < config.min_confidence:
        reasons.append(ReasonCode.CONFIDENCE_TOO_LOW)
    strategy_reasons = tuple(dict.fromkeys(reasons))
    strategy_passed = not strategy_reasons
    risk_reasons = _risk_reasons(context, config) if strategy_passed else []
    quantity: QuantityResult | None = None
    entry_ref: Decimal | None = None
    stop_price: Decimal | None = None
    target_price: Decimal | None = None
    if strategy_passed and not risk_reasons:
        side = "LONG" if feature.regime == Regime.LONG else "SHORT"
        entry_ref = reference_entry_price(feature, side, config)
        fill = paper_fill_price(entry_ref, "BUY" if side == "LONG" else "SELL", config)
        quantity = calculate_quantity(entry_price=fill, atr_value=dec(feature.atr15m), context=context, config=config)
        if quantity.rejection_code is not None:
            risk_reasons.append(quantity.rejection_code)
        else:
            stop_distance = config.atr_stop_multiplier * dec(feature.atr15m)
            target_distance = config.atr_take_profit_multiplier * dec(feature.atr15m)
            if side == "LONG":
                stop_price = fill - stop_distance
                target_price = fill + target_distance
            else:
                stop_price = fill + stop_distance
                target_price = fill - target_distance
    all_reasons = tuple(dict.fromkeys([*strategy_reasons, *risk_reasons]))
    approved = strategy_passed and not risk_reasons
    if approved:
        action = DecisionAction.ENTER_LONG if feature.regime == Regime.LONG else DecisionAction.ENTER_SHORT
    else:
        action = rejected_action
    return StrategyEvaluation(
        action=action,
        regime=feature.regime,
        confidence=components.total,
        confidence_components=components,
        reason_codes=all_reasons,
        strategy_conditions_passed=strategy_passed,
        risk_approved=approved,
        shadow_decision=strategy_passed and bool(risk_reasons),
        quantity=quantity,
        entry_price_reference=entry_ref,
        stop_price=stop_price,
        target_price=target_price,
    )


def gross_pnl(side: str, entry_price: Decimal, exit_price: Decimal, quantity: Decimal) -> Decimal:
    if side.upper() == "LONG":
        return (exit_price - entry_price) * quantity
    if side.upper() == "SHORT":
        return (entry_price - exit_price) * quantity
    raise ValueError("side must be LONG or SHORT")


def unrealized_pnl(side: str, entry_price: Decimal, executable_price: Decimal, quantity: Decimal) -> Decimal:
    return gross_pnl(side, entry_price, executable_price, quantity)


def break_even_stop(position: PositionState, config: StrategyConfig) -> Decimal:
    notional = position.entry_price * position.quantity
    expected_exit_fee = notional * config.fee_rate_per_side
    spread_slip_cost = notional * (
        config.slippage_rate_per_side + (config.estimated_spread_bps / Decimal("20000"))
    )
    total_cost = position.entry_fee + expected_exit_fee + spread_slip_cost
    per_unit = total_cost / position.quantity if position.quantity else Decimal("0")
    return position.entry_price + per_unit if position.side.upper() == "LONG" else position.entry_price - per_unit


def evaluate_exit(
    position: PositionState,
    feature: FeatureSnapshot,
    config: StrategyConfig | None = None,
    *,
    daily_circuit_breaker: bool = False,
    admin_shutdown: bool = False,
    now: datetime | None = None,
) -> ExitEvaluation:
    config = config or StrategyConfig()
    now = ensure_utc(now or feature.decision_time)
    long_side = position.side.upper() == "LONG"
    exit_action = DecisionAction.EXIT_LONG if long_side else DecisionAction.EXIT_SHORT
    if admin_shutdown:
        return ExitEvaluation(True, exit_action, ReasonCode.ADMIN_SHUTDOWN, dec(feature.close), position.stop_price, position.max_favorable_r, position.trailing_active, position.break_even_active)
    if daily_circuit_breaker:
        return ExitEvaluation(True, exit_action, ReasonCode.DAILY_CIRCUIT_BREAKER, dec(feature.close), position.stop_price, position.max_favorable_r, position.trailing_active, position.break_even_active)
    if position.stale_since is not None and now - ensure_utc(position.stale_since) >= timedelta(minutes=config.stale_exit_timeout_minutes):
        return ExitEvaluation(True, exit_action, ReasonCode.STALE_DATA_TIMEOUT, dec(feature.close), position.stop_price, position.max_favorable_r, position.trailing_active, position.break_even_active)
    if long_side and feature.regime == Regime.SHORT:
        return ExitEvaluation(True, exit_action, ReasonCode.REGIME_FLIP, dec(feature.close), position.stop_price, position.max_favorable_r, position.trailing_active, position.break_even_active)
    if not long_side and feature.regime == Regime.LONG:
        return ExitEvaluation(True, exit_action, ReasonCode.REGIME_FLIP, dec(feature.close), position.stop_price, position.max_favorable_r, position.trailing_active, position.break_even_active)

    high = dec(feature.high)
    low = dec(feature.low)
    stop_hit = low <= position.stop_price if long_side else high >= position.stop_price
    target_hit = high >= position.target_price if long_side else low <= position.target_price
    # Conservative assumption when an OHLC candle touches both: stop is first.
    if stop_hit:
        reason = ReasonCode.TRAILING_STOP if position.trailing_active else ReasonCode.BREAK_EVEN if position.break_even_active else ReasonCode.STOP_LOSS
        return ExitEvaluation(True, exit_action, reason, position.stop_price, position.stop_price, position.max_favorable_r, position.trailing_active, position.break_even_active)
    if target_hit:
        return ExitEvaluation(True, exit_action, ReasonCode.TAKE_PROFIT, position.target_price, position.stop_price, position.max_favorable_r, position.trailing_active, position.break_even_active)

    favorable_move = high - position.entry_price if long_side else position.entry_price - low
    current_max_r = max(position.max_favorable_r, favorable_move / position.initial_stop_distance if position.initial_stop_distance > 0 else Decimal("0"))
    updated_stop = position.stop_price
    break_even_active = position.break_even_active
    trailing_active = position.trailing_active
    if current_max_r >= config.break_even_at_r:
        candidate = break_even_stop(position, config)
        updated_stop = max(updated_stop, candidate) if long_side else min(updated_stop, candidate)
        break_even_active = True
    if current_max_r >= config.trailing_start_at_r:
        trail = dec(feature.close) - config.trailing_atr_multiplier * dec(feature.atr15m) if long_side else dec(feature.close) + config.trailing_atr_multiplier * dec(feature.atr15m)
        updated_stop = max(updated_stop, trail) if long_side else min(updated_stop, trail)
        trailing_active = True
    if position.bars_held >= config.time_exit_bars and current_max_r < config.time_exit_min_r:
        return ExitEvaluation(True, exit_action, ReasonCode.TIME_EXIT, dec(feature.close), updated_stop, current_max_r, trailing_active, break_even_active)
    return ExitEvaluation(False, None, None, None, updated_stop, current_max_r, trailing_active, break_even_active)


def executable_exit_reference(feature: FeatureSnapshot, side: str) -> Decimal:
    close = dec(feature.close)
    if feature.bid is not None and feature.ask is not None and feature.ask > feature.bid > 0:
        return dec(feature.bid if side.upper() == "LONG" else feature.ask)
    half_spread = dec(feature.spread_bps) / Decimal("20000")
    return close * (Decimal("1") - half_spread if side.upper() == "LONG" else Decimal("1") + half_spread)


def build_future_label(
    *,
    decision_close: datetime,
    decision_price: float,
    direction: str,
    future_bars: Sequence[CandleBar],
    horizon_minutes: int,
    stop_price: float,
    target_price: float,
    estimated_round_trip_cost_rate: float,
) -> FutureLabel:
    decision_close = ensure_utc(decision_close)
    horizon_end = decision_close + timedelta(minutes=horizon_minutes)
    eligible = [bar for bar in future_bars if bar.open_time >= decision_close and bar.close_time <= horizon_end and bar.complete]
    if not eligible or eligible[-1].close_time < horizon_end:
        return FutureLabel(available=False, horizon_minutes=horizon_minutes, data_complete=False)
    long_side = direction.upper() == "LONG"
    final_return = (eligible[-1].close / decision_price) - 1.0
    if not long_side:
        final_return = -final_return
    favorable = max((bar.high / decision_price) - 1.0 for bar in eligible) if long_side else max(1.0 - (bar.low / decision_price) for bar in eligible)
    adverse = min((bar.low / decision_price) - 1.0 for bar in eligible) if long_side else min(1.0 - (bar.high / decision_price) for bar in eligible)
    stop_time: int | None = None
    target_time: int | None = None
    for bar in eligible:
        elapsed = int((bar.close_time - decision_close).total_seconds())
        if stop_time is None and ((bar.low <= stop_price) if long_side else (bar.high >= stop_price)):
            stop_time = elapsed
        if target_time is None and ((bar.high >= target_price) if long_side else (bar.low <= target_price)):
            target_time = elapsed
    stop_first = stop_time is not None and (target_time is None or stop_time <= target_time)
    target_first = target_time is not None and (stop_time is None or target_time < stop_time)
    return FutureLabel(
        available=True,
        horizon_minutes=horizon_minutes,
        future_return=final_return,
        future_return_after_costs=final_return - estimated_round_trip_cost_rate,
        maximum_favorable_excursion=favorable,
        maximum_adverse_excursion=adverse,
        stop_reached_first=stop_first,
        target_reached_first=target_first,
        time_to_stop_seconds=stop_time,
        time_to_target_seconds=target_time,
        data_complete=True,
    )


@dataclass
class LedgerTrade:
    order_id: str
    fill_id: str
    position_id: str
    side: str
    quantity: Decimal
    price: Decimal
    fee: Decimal
    realized_pnl: Decimal
    action: str


class PaperLedger:
    """Small deterministic paper ledger used by unit tests and recovery checks."""

    def __init__(self, starting_cash: Decimal | str = Decimal("10000")) -> None:
        self.cash = dec(starting_cash)
        self.realized_trading_pnl = Decimal("0")
        self.total_fees = Decimal("0")
        self.positions: dict[str, PositionState] = {}
        self.orders: set[str] = set()
        self.fills: set[str] = set()
        self.close_events: set[str] = set()
        self.trades: list[LedgerTrade] = []

    def open_position(
        self,
        *,
        symbol: str,
        side: str,
        quantity: Decimal,
        fill_price: Decimal,
        order_id: str,
        fill_id: str,
        position_id: str,
        stop_price: Decimal,
        target_price: Decimal,
        atr_value: Decimal,
        fee_rate: Decimal = Decimal("0.0004"),
    ) -> LedgerTrade:
        if symbol in self.positions:
            raise ValueError(ReasonCode.POSITION_ALREADY_OPEN.value)
        if order_id in self.orders:
            raise ValueError(ReasonCode.DUPLICATE_ORDER.value)
        if fill_id in self.fills:
            raise ValueError(ReasonCode.DUPLICATE_FILL.value)
        fee = fill_price * quantity * fee_rate
        self.cash -= fee
        self.total_fees += fee
        position = PositionState(
            position_id=position_id,
            symbol=symbol,
            side=side,
            quantity=quantity,
            entry_price=fill_price,
            initial_stop_distance=abs(fill_price - stop_price),
            stop_price=stop_price,
            target_price=target_price,
            atr_at_entry=atr_value,
            opened_at=utc_now(),
            entry_fee=fee,
        )
        self.positions[symbol] = position
        self.orders.add(order_id)
        self.fills.add(fill_id)
        trade = LedgerTrade(order_id, fill_id, position_id, side, quantity, fill_price, fee, Decimal("0"), "OPEN")
        self.trades.append(trade)
        return trade

    def close_position(
        self,
        *,
        symbol: str,
        exit_price: Decimal,
        order_id: str,
        fill_id: str,
        close_event_id: str,
        fee_rate: Decimal = Decimal("0.0004"),
    ) -> LedgerTrade:
        if close_event_id in self.close_events:
            raise ValueError("duplicate close event")
        if order_id in self.orders:
            raise ValueError(ReasonCode.DUPLICATE_ORDER.value)
        if fill_id in self.fills:
            raise ValueError(ReasonCode.DUPLICATE_FILL.value)
        position = self.positions.pop(symbol)
        fee = exit_price * position.quantity * fee_rate
        pnl = gross_pnl(position.side, position.entry_price, exit_price, position.quantity)
        self.cash += pnl - fee
        self.realized_trading_pnl += pnl
        self.total_fees += fee
        self.orders.add(order_id)
        self.fills.add(fill_id)
        self.close_events.add(close_event_id)
        trade = LedgerTrade(order_id, fill_id, position.position_id, position.side, position.quantity, exit_price, fee, pnl, "CLOSE")
        self.trades.append(trade)
        return trade

    def equity(self, executable_prices: dict[str, Decimal] | None = None) -> Decimal:
        prices = executable_prices or {}
        unrealized = sum(
            (gross_pnl(position.side, position.entry_price, prices.get(symbol, position.entry_price), position.quantity) for symbol, position in self.positions.items()),
            Decimal("0"),
        )
        return self.cash + unrealized

    def snapshot(self) -> dict[str, Any]:
        return {
            "cash": str(self.cash),
            "realized_trading_pnl": str(self.realized_trading_pnl),
            "total_fees": str(self.total_fees),
            "positions": {
                symbol: {
                    **asdict(position),
                    "quantity": str(position.quantity),
                    "entry_price": str(position.entry_price),
                    "initial_stop_distance": str(position.initial_stop_distance),
                    "stop_price": str(position.stop_price),
                    "target_price": str(position.target_price),
                    "atr_at_entry": str(position.atr_at_entry),
                    "max_favorable_r": str(position.max_favorable_r),
                    "entry_fee": str(position.entry_fee),
                    "exit_fee": str(position.exit_fee),
                    "opened_at": position.opened_at.isoformat(),
                    "stale_since": position.stale_since.isoformat() if position.stale_since else None,
                }
                for symbol, position in self.positions.items()
            },
            "orders": sorted(self.orders),
            "fills": sorted(self.fills),
            "close_events": sorted(self.close_events),
        }

    @classmethod
    def restore(cls, payload: dict[str, Any]) -> "PaperLedger":
        ledger = cls(payload["cash"])
        ledger.realized_trading_pnl = dec(payload["realized_trading_pnl"])
        ledger.total_fees = dec(payload["total_fees"])
        ledger.orders = set(payload.get("orders", []))
        ledger.fills = set(payload.get("fills", []))
        ledger.close_events = set(payload.get("close_events", []))
        for symbol, raw in payload.get("positions", {}).items():
            ledger.positions[symbol] = PositionState(
                position_id=raw["position_id"],
                symbol=raw["symbol"],
                side=raw["side"],
                quantity=dec(raw["quantity"]),
                entry_price=dec(raw["entry_price"]),
                initial_stop_distance=dec(raw["initial_stop_distance"]),
                stop_price=dec(raw["stop_price"]),
                target_price=dec(raw["target_price"]),
                atr_at_entry=dec(raw["atr_at_entry"]),
                opened_at=datetime.fromisoformat(raw["opened_at"]),
                bars_held=int(raw.get("bars_held", 0)),
                max_favorable_r=dec(raw.get("max_favorable_r", "0")),
                entry_fee=dec(raw.get("entry_fee", "0")),
                exit_fee=dec(raw.get("exit_fee", "0")),
                stale_since=datetime.fromisoformat(raw["stale_since"]) if raw.get("stale_since") else None,
                trailing_active=bool(raw.get("trailing_active", False)),
                break_even_active=bool(raw.get("break_even_active", False)),
            )
        return ledger
